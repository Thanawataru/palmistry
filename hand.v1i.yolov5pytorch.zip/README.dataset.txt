# hand > 2023-07-26 4:30pm
https://universe.roboflow.com/thai-thun-pfjrp/hand-slzri

Provided by a Roboflow user
License: CC BY 4.0

